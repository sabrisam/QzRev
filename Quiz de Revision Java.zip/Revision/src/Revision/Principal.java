package Revision;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {

		// TODO Auto-generated method stub
		Quiz quiz = new Quiz(0);
		quiz.entete();
		quiz.start();
		quiz.displayResult();
		
		

	}

}



//il reste le score
//il reste le temps
//il reste le msg derreur rouge
