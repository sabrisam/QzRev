package Revision;

public class Question {
	private String qst;
	private String rps;
	
	public Question (String qst, String rps) {
		this.qst = qst;
		this.rps = rps;
		
		
	}

	public String getQst() {
		return qst;
	}

	public String getRps() {
		return rps;
	}
}








//public class questions extends qstns{
//	 
//	private String question;
//	private String reponse;
//	private List<String> choix = new ArrayList<String>();
// 
//	public questions(String question, String reponse, String mauvaiseReponse) {
//		this.question = question;
//		this.reponse = reponse;
//		this.choix.add(reponse);
//		this.choix.add(mauvaiseReponse);
//	}
// 
//	public String getQuestion() {
//		return question;
//	}
//
//	public List<String> getChoix() {
//		return choix;
//	}
// 
//	public boolean isReponse(String reponse) {
//		return this.reponse.equals(reponse);
//	}
// 
//}