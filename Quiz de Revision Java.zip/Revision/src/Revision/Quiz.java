package Revision;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

public class Quiz {
	private int nbQuestions;
	private int score;
	private long tempsEcoule;
	Scanner clavier = new Scanner(System.in);

	
	
	
	
	
	
	
	public Quiz(int nbQuestions) {
		this.nbQuestions = nbQuestions;
	}

	
	
	
	public void entete() {
		System.out.println( // en-tete
				"---------------------  QUIZ DE REVISION  --------------------- \nRepondre par vrai ou faux pour toutes les questions suivantes "
						+ "\n" + "\n" + "\n" + "\n 	    ***********  INSTRUCTIONS   *********** \n\n" +"Pour repondre Vrai, il faut UNIQUEMENT tapper V ensuite ENTER\n" + 
						"Pour repondre Faux, il faut UNIQUEMENT tapper F ensuite ENTER" + "\n" + "\n" + "\n" + "\n\n\n                        Salam3alikoum               ");
	}
	
	public void start() {
		try {
			
			long startTime = System.currentTimeMillis(); // debut du chrono

			Scanner clav = new Scanner(System.in); // variable du clavier
			try {
				System.out.println("                         ∞∞∞∞∞∞∞∞∞∞∞                     "); // cm de qustns
				System.out.println("            tu veux reviser combien de questions ?"); // cm de qustns
				// nextInt will throw InputMismatchException
				// if the next token does not match the Integer
				// regular expression, or is out of range
				int usrQst = clav.nextInt(); // variable de ce qui est saisie au clavier
				nbQuestions = usrQst; // le nombre de questions devient le nombre que lutilisateur a saisie
			} catch (InputMismatchException exception) { // si lutilisateur ne choisie pas un chiffre
				// Print "This is not an integer"
				// when user put other than integer
				System.out.println( //message d'erreur 
						"\n\n\n              t bete ou quoi ? METS UN CHIFFRE !  ");
				System.out.println( //message d'erreur 
						"              ----------------------------------  \n\n\n\n");
		
			}

			for (Question question : generate(nbQuestions)) {

				System.out.println(question.getQst()); // la question
				String userAnswer = clavier.nextLine(); // reponse utilisateur

				if (userAnswer.isEmpty()) {
					System.out.println("ECRIS QQUE CHOSE");
				} else {

					if (userAnswer.equalsIgnoreCase(question.getRps())) { // si la reponse est bonne
						score++;
						System.out.println(
								"\n   ==> BONNE REPONSE\n       Ouais Ouais Ouais !! wlh t'as dead mais avoue ste dla chance\n");
					} else { // si la reponse est mauvaise
						System.out.println(
								"\n   ==> MAUVAISE REPONSE\n       T nul ... artoun etudier osti dnieseux a marde\n");
					}
					System.out.println("--------------------------------------------------------------\n");
				}
			}

			long endTime = System.currentTimeMillis();
			tempsEcoule = (endTime - startTime);

		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
			start();
		}
	}

	
	
	
	
	
	
	
	
	
	
	
	
	private int getTimeElapsedInSeconds(long timeInMilliseconds) {
		return (int) (timeInMilliseconds / 1000);
	}
	
	public void displayResult() {
		
		if (nbQuestions > 0) {
			
		
		if (tempsEcoule > 0) {
			System.out.println("                         RESULTATS : \n");
			System.out.printf("               T'as un score de %d/%d ma gueule ! \n\n", score, nbQuestions);
			System.out.printf(
					"                         En passant,\n                t'as fais ca en %d secondes...\n            juste pour ton information personnel\n                        tse veu dire  ",
					getTimeElapsedInSeconds(tempsEcoule), nbQuestions);
		}}
		else {
			start();
		}
			
	}

	
	
	
	
	
	
	
	
	
	private ArrayList<Question> generate(int nbQuestions) {
		String[][] data = getData();

		// pour ne pas avoir de boucle infinie
		if (nbQuestions > data.length) {
			throw new IllegalArgumentException(
					"\n\n\n\n             ∆˚˚∆˚˚∆˚˚∆˚˚   ERREUR    ˚˚∆˚˚∆˚˚∆˚˚∆              \n\n\n                      Non mais Rhololo!\n              j'ai maximum "
							+ data.length
							+ " questions pour toi\n                        ten veut cmb?\n\n\n             ∆˚˚∆˚˚∆˚˚∆˚˚    MERCI    ˚˚∆˚˚∆˚˚∆˚˚∆              \n\n\n\n");
		}
		
		
		ArrayList<Question> questions = new ArrayList<Question>();

		int index;

		ArrayList<Integer> indexesAlreadyTaken = new ArrayList<>();

		for (int i = 0; i < nbQuestions; i++) { // choisir questions de maniere aleatoire
			do {
				Random random = new Random();
				index = random.nextInt(data.length);
			} while (indexesAlreadyTaken.contains(index));

			indexesAlreadyTaken.add(index);

			String laQuestion = data[index][0];
			String laReponse = data[index][1];

			questions.add(new Question(laQuestion, laReponse));
		}
		return questions;
	}

	
	
	
	
	
	
	
	
	// les donnees des questions et reponses
	private static String[][] getData() {
		String[][] data = { {
				"Question 1. Si la classe A étend (extends) la classe B, alors la classe A est une sous classe et la classe B est une super classe",
				"v" }, { "Question 2. Une instance d’une sous classe est aussi une instance de sa super classe.", "v" },
				{ "Question 3. Une instance de la super classe peut être traitée comme si elle est une instance de la sous classe.",
						"f" },
				{ "Question 4. Polymorphisme signifie que la méthode évoquée dépend de la classe de l’instance.", "v" },
				{ "Question 5. Un attribut public d’une classe est hérité par une sous classe, mais pas un attribut private.",
						"f" },
				{ "Question 6. Une sous classe ne peut avoir qu’une super classe.", "v" },
				{ "Question 7. Une classe concrète peut avoir une sous classe abstraite.", "v" },
				{ "Question 8. Une sous classe concrète peut avoir plusieurs super classes abstraites, àcondition que ces super classes abstraites n’aient pas de conflit entre elles.",
						"f" },
				{ "Question 9. Une classe peut implante une ou plusieurs interfaces.", "v" },
				{ "Question 10. La seule différence entre une interface et une classe abstraite est qu’une interface ne peut pas implanter de méthode, mais une classe abstraite le peut.",
						"f" },
				{ "Question 11. Si dans une méthode, la valeur d’un paramètre est modifiée, le paramètre garde sa nouvelle valeur àla sortie de la méthode.",
						"v" },
				{ "Question 12. Le casting d’une valeur primitive signifie la transformer en un autre type de valeur.", "v" },
				{ "Question 13. Le casting d’une référence d’objet signifie transformer l’objet en un objet d’une autre classe.",
						"f" },
				{ "Question 14. La comparaison == de deux références d’objet retourne vrai si les deux objets référés sont des copies conformes.",
						"f" },
				{ "Question 15. Dans une boucle for, si l’index dépasse les limites, le compilateur ne détecte pas l’erreur.",
						"v" } };
		return data;
	}

}